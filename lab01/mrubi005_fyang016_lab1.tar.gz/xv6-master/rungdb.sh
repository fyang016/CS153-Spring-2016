#!/bin/bash

gdb -q -iex "set auto-load safe-path ./"
